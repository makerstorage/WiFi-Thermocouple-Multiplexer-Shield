# vue-frontend

ESP-DASH Vuejs Files for customization and trust. Please try to give back to the open source community after customizing. It is a open source property and should NOT be transformed into a closed source project or get rebranded.

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```
Warning: `app.js` will be Gzipped with .gz extension!


### Compiles and minifies for production
```
npm run build
```

Warning: `app.js` will be Gzipped with .gz extension!

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```
